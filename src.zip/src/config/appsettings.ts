export const APP_CONFIG = {
    UID: 'C6htuYeBxoOhkePXbCYAD0aYVzN2'
}